<?php
$koneksi = mysqli_connect('localhost','root','','sekolah_rangga');

?>     