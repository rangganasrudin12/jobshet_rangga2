<!DOCTYPE html>
<html>
<head>
  <title>DATA JURUSAN</title>
  <link rel="stylesheet" type="text/css" href="../asset/style/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../asset/style/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="../asset/style/css/bootstrap-theme.min.css">
  <link rel="stylesheet" type="text/css" href="../asset/style/css/bootstrap-theme.css">
  <link rel="stylesheet" type="text/css" href="../asset/style/css/style.css">
</head>
<body>



  <nav class="navbar navbar-light" style="background: limegreen">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        
        <li><a href="datasiswa.php">DATA SISWA</a></li>
        <li><a href="datakelas.php">DATA KELAS</a></li> 
        <li><a href="datajurusan.php">DATA JURUSAN</a></li>
       
      </ul>
      <form class="navbar-form navbar-left">
        <div class="formaceng-group">
          <input type="text" class="form-control" placeholder="Search">
        </div>

      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="logout.php">LOGOUT</a></li>
       
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="container">
	<div class="row">
	<div class="col-lg-12">
	<h2 align="left">Data Jurusan</h2>
  <br>  
  <center>  
      <a class="btn btn-success" href="tambahdatajurusan.php"><i class="glyphicon glyphicon-user"></i>TAMBAH DATA JURUSAN</a>
      <a class="btn btn-success" href="upload_kelas_import.php"><i class="glyphicon glyphicon-user"></i>Import</a>
       <a class="btn btn-success" href="export/pdf/siswa.php"><i class="glyphicon glyphicon-user"></i>Export To PDF</a>

  </center>
</br>
	<?php

	include'koneksi.php' ;



	$sql ='SELECT * From jurusan';

	     $query = mysqli_query($koneksi, $sql);

	     if (!$query) {
	     	die ('SQL error: ' . mysqli_error($koneksi));
	     }


echo '<div class="table-responsive">
<table class="table table-bordered">
   <thead>
   <tr>

         <th>Nama Jurusan</th>
         <th>Keterangan</th>
         <th>action</th>
     </tr>
     </thead>
     <tbody>';

     while ($row = mysqli_fetch_array($query))

   {
   	echo "<tr>



     <td>".$row['nama_jurusan']."</td>
     <td>".$row['keterangan']."</td>

     <td><a href='edit_jurusan.php?id_jurusan=$row[id_jurusan]' class='u'>edit</a>
     <a href='aksi/delete_jurusan.php?id_jurusan=$row[id_jurusan]' class='ui')>delete</a>
     </td>

     </tr>";
   }
   echo '
     </tbody>
     </table>
     </div>';


     ?>
        </div>
       </div>
       </div>
       <div class="footer">
       <div class="container">
       <div class="row">
       <div class="col-lg-12">

       &copy; 2019. Rangga Nasrudin
</div>
</div>
</div>
</div>

    


     
     



</body>
</html>