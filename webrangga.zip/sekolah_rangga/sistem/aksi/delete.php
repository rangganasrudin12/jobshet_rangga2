<?php
include'../koneksi.php';
$id = $_GET['id_siswa'];

$sql="DELETE from siswa where id_siswa='$id'";
$query= mysqli_query($koneksi, $sql);
echo "<script>window.alert('Data suksess di Hapus')
		window.location='../datasiswa.php'
	</script>";
 ?> 