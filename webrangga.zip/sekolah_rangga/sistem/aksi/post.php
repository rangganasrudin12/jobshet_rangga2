<!DOCTYPE html>

<html>
<head>
	<title>Validasi</title>
</head>
<body>


<?php
include '../koneksi.php';

	$id_kelas = $_POST['id_kelas'];
	$nis = $_POST['nis'];
	$nama = $_POST['nama'];
	$jenis = $_POST['jenis'];
	$alamat = $_POST['alamat'];

	$nama_file =$_FILES['img']['name'];
	$file_tmp = $_FILES['img']['tmp_name'];
	$pach="../../asset/gambar/".$nama_file;
	move_uploaded_file($file_tmp, $pach);
	$Rangga ="SELECT * from siswa where nis='$nis'";
	$Rangga = mysqli_query($koneksi, $Rangga);
	$cek = mysqli_num_rows($Rangga);
	if ($cek > 0) {
		echo "<script>window.alert('Nis yang anda masukan sudah ada!!!')
			window.location='../datasiswa.php'
		</script>";
	}else{
		$sql ="INSERT into siswa values(null,'$id_kelas','$nis','$nama','$jenis','$alamat','$nama_file') ";
	$query = mysqli_query($koneksi, $sql) or die ('Sql Error:'.mysqli_error($koneksi));
	echo "<script>window.alert('Data Di Simpan')
			window.location='../datasiswa.php'
		</script>";
}


?>
</body>
</html>
