<?php
include'../koneksi.php';
$id = $_GET['id_jurusan'];

$sql="DELETE from jurusan where id_jurusan='$id'";
$query= mysqli_query($koneksi, $sql);
echo "<script>window.alert('Data suksess di Hapus')
		window.location='../datajurusan.php'
	</script>";
 ?> 