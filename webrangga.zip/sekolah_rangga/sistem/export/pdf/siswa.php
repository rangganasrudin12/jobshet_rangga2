<?php 
 include"../koneksi.php";
require_once(".../asset/dompdf/autoload.inc.php");
use Dompdf\Dompdf;
$dompdf = new Dompdf();
$sql="SELECT * FROM siswa INNER JOIN kelas ON siswa.id_kelas=kelas.id_kelas JOIN jurusan on kelas.id_jurusan=jurusan.id_jurusan";
$query = mysqli_query($koneksi,$sql);
$html = '<center><h3>Daftar siswa</h3></center>';
$html .= '<table border="1" width="100">';
<tr>

         <th>no</th>
        
         <th>nis</th>
         <th>nama</th>
         <th>jenis_kelamin</th>
         <th>alamat</th>
         <th>kelas</th>
         <th>jurusan</th>
       
     </tr>;
     $no = 1;
     while ($row = mysqli_fetch_array($query))
      {
     	$html .="<tr>

     	<td>".$no."</td>
     	<td>".$row['nis']."</td>
     	<td>".$row['nama']."</td>
     	<td>".$row['jenis_kelamin']."</td>
     	<td>".$row['alamat']."</td>
     	<td>".$row['nama_kelas']."</td>
     	<td>".$row['nama_jurusan']."</td>
     	</tr>";
     	$no++;
     }
$html.="</html>";
$dompdf->loadHtml($html);
$dompdf->setPaper('A4','potrait');
$dompdf->render();
$dompdf->Stream('laporan_siswa.pdf');

 ?>\
  