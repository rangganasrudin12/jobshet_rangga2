<?php 

header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Data kelas.xls");
 ?>


 <table border="1">
 	<tr>
         <th>No</th>
         <th>Nama Kelas</th>
         <th>Program Keahlian</th>
         <th>Tingkat</th>
         <th>Keterangan</th>

     </tr>
     <?php 
     include"../koneksi.php";
$sql ='SELECT *  FROM kelas INNER JOIN jurusan on kelas.id_jurusan=jurusan.id_jurusan';
 $query = mysqli_query($koneksi, $sql);
 $no = 1;
 while ($row = mysqli_fetch_array($query)) {
 	?>
 	<tr>
     <td> <?php echo $no++; ?></td>

     <td> <?php echo $row['nama_kelas']; ?></td>
     <td> <?php echo $row['nama_jurusan']; ?></td>
     <td> <?php echo $row['tingkat']; ?></td>
     <td> <?php echo $row['keterangan']; ?></td>

     
</tr>
<?php
}
 ?>

    
  
 </table>