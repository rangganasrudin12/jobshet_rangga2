<?php 
include'koneksi.php';

if($_GET['act']== 'tambahuser'){ 
	$id =@$_POST['id_jurusan'];
	$Nama =@$_POST['nama_jurusan'];

	$keterangan=@$_POST['keterangan'];

$sqli = " UPDATE jurusan SET  nama_jurusan='$Nama', keterangan='$keterangan' where id_jurusan='$id'";
$query = mysqli_query($koneksi, $sqli);
echo "<script>window.alert('Data suksess di ubah')
		window.location='datajurusan.php'
	</script>";


}


 ?>