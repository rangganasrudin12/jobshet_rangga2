<?php 
include'koneksi.php';

if($_GET['act']== 'tambahuser'){ $id =@$_POST['id_siswa']; $Nis
=@$_POST['nis']; $Nama =@$_POST['nama_siswa']; $Jenis =@$_POST['jl']; $Alamat
=@$_POST['Alamat'];

$nama_file =$_FILES['img']['name'];
$file_tmp = $_FILES['img']['tmp_name'];
$pach="../asset/gambar/".$nama_file;
move_uploaded_file($file_tmp, $pach);

$sqli = " UPDATE siswa SET nis='$Nis', nama='$Nama', jenis_kelamin='$Jenis', alamat='$Alamat',poto='$nama_file' where id_siswa='$id'";
$query = mysqli_query($koneksi, $sqli);
echo "<script>window.alert('Data suksess di ubah')
		window.location='datasiswa.php'
	</script>";


}


 ?>