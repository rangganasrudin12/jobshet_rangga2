<?php 
include'koneksi.php';

if($_GET['act']== 'edit'){ 
	$id =@$_POST['id_kelas']; 
	$Nama =@$_POST['nama_kelas'];
	$tingkat=@$_POST['tingkat'];



$sqli = " UPDATE kelas SET nama_kelas='$Nama', tingkat='$tingkat' where id_kelas='$id'";
$query = mysqli_query($koneksi, $sqli);
echo "<script>window.alert('Data suksess di ubah')
		window.location='datakelas.php'
	</script>";


}


 ?>